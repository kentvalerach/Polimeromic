```python
# Cleanup of the Sixth block of the BIOGRID file preserving compatibility for merging
# Limpieza del Sexto bloque del archivo BIOGRID conservanndo compatibilidad para fusion

from sklearn.preprocessing import MinMaxScaler
import matplotlib.pyplot as plt
import pandas as pd

# Global setting to avoid scientific notation
# Configuración global para evitar notación científica
pd.options.display.float_format = '{:.12g}'.format

# Path of the file to be processed
# Ruta del archivo a procesar
input_file = r'C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6.csv'
output_file = r'C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6_refined.csv'

# Read the processed file
# Leer el archivo procesado
print("Cargando archivo para refinamiento...")
data = pd.read_csv(input_file, low_memory=False)

# Step 1: Handling null values in key columns
# Paso 1: Manejo de valores nulos en columnas clave
print("Imputando valores nulos y eliminando columnas vacías...")

# Fill null values in key columns
# Rellenar valores nulos en columnas clave
if 'ALIASES' in data.columns:
    data['ALIASES'].fillna("UNKNOWN", inplace=True)

for col in ['SCORE.2', 'SCORE.3', 'SCORE.4', 'SCORE.5']:
    if col in data.columns:
        data[col] = pd.to_numeric(data[col], errors='coerce')  # Convertir a numérico, NaN si no puede
        median_value = data[col].median()  # Calcular la mediana para imputar valores faltantes
        data[col].fillna(median_value, inplace=True)  # Rellenar valores nulos con la mediana

# Eliminate completely null columns
# Eliminar columnas completamente nulas
columns_to_drop = [col for col in data.columns if data[col].isnull().all()]
print(f"Columnas eliminadas por estar completamente vacías: {columns_to_drop}")
data.drop(columns=columns_to_drop, inplace=True, errors='ignore')

# Step 2: Eliminate redundant columns
# Paso 2: Eliminar columnas redundantes y constantes
print("Eliminando columnas redundantes y constantes...")
redundant_columns = ['SOURCE', 'ORGANISM_ID', 'SCORE.3', 'SCORE.4', 'SCORE.5', '#SCREEN_ID']
data.drop(columns=redundant_columns, inplace=True, errors='ignore')

# Step 3: Review and treat outliers in SCORE.1
# Paso 3: Revisar y tratar valores extremos en SCORE.1 y otras columnas numéricas
print("Verificando y tratando valores extremos...")
numeric_columns = data.select_dtypes(include=['float64', 'int64']).columns

for col in numeric_columns:
    q1 = data[col].quantile(0.25)
    q3 = data[col].quantile(0.75)
    iqr = q3 - q1
    lower_bound = q1 - 1.5 * iqr
    upper_bound = q3 + 1.5 * iqr

    # Replace extreme values by reasonable limits
    # Reemplazar valores extremos por límites razonables
    data[col] = data[col].apply(
        lambda x: lower_bound if x < lower_bound else upper_bound if x > upper_bound else x
    )

# Step 4: Normalize numeric columns
# Paso 4: Normalizar columnas numéricas
print("Normalizando columnas numéricas...")
scaler = MinMaxScaler()

for col in numeric_columns:
    data[col] = scaler.fit_transform(data[[col]])

# Step 5: Eliminate scientific notation and limit to 30 digits
# Paso 5: Eliminar notación científica y limitar a 30 dígitos
print("Eliminando notación científica y limitando dígitos...")
def format_numeric_columns(df, columns):
    for column in columns:
        df[column] = df[column].apply(lambda x: f"{x:.30g}" if isinstance(x, (int, float)) else x)
    return df

data = format_numeric_columns(data, numeric_columns)

# Step 6: Remove duplicates based on key columns
# Paso 6: Eliminar duplicados basados en columnas clave
print("Eliminando duplicados basados en columnas clave...")
columns_to_consider = ['IDENTIFIER_ID', 'IDENTIFIER_TYPE', 'OFFICIAL_SYMBOL'] + list(numeric_columns)
data.drop_duplicates(subset=columns_to_consider, inplace=True)

# Step 7: Validate final integrity
# Paso 7: Validar integridad final
print("Validando integridad de datos...")
data.fillna("UNKNOWN", inplace=True)

# Step 8: Visualizations
# Paso 8: Visualizaciones
print("Generando visualizaciones...")
plt.figure(figsize=(10, 6))

# Histogram of numerical columns
# Histograma de columnas numéricas
for col in numeric_columns:
    plt.hist(data[col].astype(float), bins=50, alpha=0.7, label=col)
    plt.title(f'Distribución de {col}')
    plt.xlabel(f'{col} (Normalizado)')
    plt.ylabel('Frecuencia')
    plt.legend()
    plt.savefig(f'{col}_distribution_block4.png')
    plt.show()

# Step 9: Save refined file
# Paso 9: Guardar archivo refinado
print("Guardando el archivo refinado...")
data.to_csv(output_file, index=False)

print(f"Archivo refinado guardado en {output_file}")
```

    Cargando archivo para refinamiento...
    Imputando valores nulos y eliminando columnas vacías...
    Columnas eliminadas por estar completamente vacías: []
    Eliminando columnas redundantes y constantes...
    Verificando y tratando valores extremos...
    Normalizando columnas numéricas...
    Eliminando notación científica y limitando dígitos...
    Eliminando duplicados basados en columnas clave...
    Validando integridad de datos...
    Generando visualizaciones...
    


    
![png](output_0_1.png)
    



    
![png](output_0_2.png)
    


    Guardando el archivo refinado...
    Archivo refinado guardado en C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6_refined.csv
    


```python
# I check again and generate a report with file characteristics, check for duplicates, etc.
# Reviso nuevamente y genero  un reporte con las caracteristicas del archivo, revision de duplicados, etc

# Path of the file to be analyzed
# Ruta del archivo a analizar
file_to_analyze = r'C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6_refined.csv'
report_file = r'C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6_refined_report_1.txt'

# Read the file
# Leer el archivo
print("Cargando el archivo para análisis...")
data = pd.read_csv(file_to_analyze, low_memory=False)

# Initialize report
# Inicializar reporte
report = []

# Step 1: General file information
# Paso 1: Información general del archivo
report.append("=== Información general ===")
report.append(f"Número de filas: {data.shape[0]}")
report.append(f"Número de columnas: {data.shape[1]}")

# Step 2: Data types and columns
# Paso 2: Tipos de datos y columnas
report.append("\n=== Tipos de datos y columnas ===")
report.append(data.dtypes.to_string())

# Step 3: Duplicates
# Paso 3: Duplicados
duplicates_count = data.duplicated().sum()
report.append(f"\n=== Duplicados ===")
report.append(f"Número de duplicados: {duplicates_count}")

# Step 4: Null values
# Paso 4: Valores nulos
null_summary = data.isnull().sum()
columns_with_nulls = null_summary[null_summary > 0]
report.append("\n=== Valores nulos ===")
if not columns_with_nulls.empty:
    report.append(columns_with_nulls.to_string())
else:
    report.append("No hay valores nulos.")

# Step 5: Descriptive statistics
# Paso 5: Estadísticas descriptivas
report.append("\n=== Estadísticas descriptivas ===")
report.append(data.describe(include='all', percentiles=[0.25, 0.5, 0.75]).to_string())

# Step 6: Unique values per column
# Paso 6: Valores únicos por columna
report.append("\n=== Valores únicos por columna ===")
unique_counts = data.nunique()
report.append(unique_counts.to_string())

# Step 7: File size
# Paso 7: Tamaño del archivo
file_size_mb = data.memory_usage(index=True).sum() / (1024 ** 2)
report.append("\n=== Tamaño del archivo ===")
report.append(f"Tamaño en memoria: {file_size_mb:.2f} MB")

# Save report
# Guardar reporte
print("Generando reporte...")
with open(report_file, 'w') as file:
    file.write("\n".join(report))

print(f"Reporte generado y guardado en {report_file}")
```

    Cargando el archivo para análisis...
    Generando reporte...
    Reporte generado y guardado en C:/Polimeromics/data/BIOGRID-CSV/cleaned_blocks/cleaned_block_6_refined_report_1.txt
    


```python

```
